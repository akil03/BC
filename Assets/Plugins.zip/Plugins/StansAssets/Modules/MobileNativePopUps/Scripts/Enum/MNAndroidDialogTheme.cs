﻿using UnityEngine;
using System.Collections;

public enum MNAndroidDialogTheme {
    ThemeDeviceDefaultDark,
    ThemeDeviceDefaultLight,
    ThemeHoloDark,
    ThemeHoloLight,
    ThemeTraditional
}
