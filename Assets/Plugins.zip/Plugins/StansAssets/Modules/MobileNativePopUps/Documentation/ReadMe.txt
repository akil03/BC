Documentation:
Documentation links is inside Unity Main Menu:

Window -> Stan's Assets -> Android Native

Support:
https://stansassets.com/#contacts

More Products:
https://goo.gl/PE66IU
